data:extend({

{
	type = "technology",
	name = "fusion-reactions",
	icon = "__FusionPower__/graphics/fusion_tech.png",
	prerequisites = {"speed-module-3", "effectivity-module-3"},
	effects =
    {
	  {
		type = "unlock-recipe",
		recipe = "deuterium"
	  },
	  {
		type = "unlock-recipe",
		recipe = "tritium"
	  },
	  {
		type = "unlock-recipe",
		recipe = "fusion-reactor"
	  }
	},
	unit =
    {
      count = 600,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
	{"alien-science-pack", 1}
      },
      time = 60
    },
	order = "i-g-c"
},
{
	type = "technology",
	name = "plasma-generator",
	icon = "__FusionPower__/graphics/core_tech.png",
	effects =
    {
      {
        type = "unlock-recipe",
        recipe = "plasma-generator"
      },
	  {
		type = "unlock-recipe",
		recipe = "hydrogen-plasma"
	  }
	},
	unit =
    {
      count = 800,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
	{"alien-science-pack", 1}
      },
      time = 60
    },
	prerequisites = {"fusion-reactions"},
	order = "i-g-c"
}

})