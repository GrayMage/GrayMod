data:extend({
  {
    type = "fluid",
    name = "deuterium",
    default_temperature = 15,
	max_temperature = 100,
    heat_capacity = "1KJ",
    base_color = {r=0.3, g=0.0, b=0.1},
    flow_color = {r=0.3, g=0.0, b=0.1},
    icon = "__FusionPower__/graphics/deuterium.png",
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
	subgroup = "intermediate-product",
    order = "i[deuterium-fluid]"
  },
  {
    type = "fluid",
    name = "tritium",
    default_temperature = 15,
	max_temperature = 100,
    heat_capacity = "100KJ",
    base_color = {r=0.3, g=0.3, b=0.0},
    flow_color = {r=0.3, g=0.3, b=0.0},
    icon = "__FusionPower__/graphics/tritium.png",
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
	subgroup = "intermediate-product",
    order = "i[tritium-fluid]"
  },
  {
	type = "fluid",
	name = "hydrogen-plasma",
	default_temperature = 150,
	max_temperature = 1000,
	heat_capacity = "1000KJ",
	base_color = {r=0.9, g=0.9, b=0.7},
	flow_color = {r=0.9, g=0.9, b=0.7},
	icon = "__FusionPower__/graphics/plasma.png",
	pressure_to_speed_ratio = 0.8,
    flow_to_energy_ratio = 0.8,
	subgroup = "intermediate-product",
    order = "a[tritium-fluid]"
  }
})