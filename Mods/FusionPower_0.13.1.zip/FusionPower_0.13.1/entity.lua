data:extend({
{
    type = "generator",
    name = "plasma-generator",
    icon = "__FusionPower__/graphics/core.png",
    flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = 1, result = "plasma-generator"},
    max_health = 6000,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    effectivity = 600.0,
    fluid_usage_per_tick = 0.1,
    resistances =
    {
      {
        type = "fire",
        percent = 70
      }
    },
    collision_box = {{-2.0, -2.0}, {2.0, 2.0}},
	selection_box = {{-2.0, -2.0}, {2.0, 2.0}},
    fluid_box =
    {
      base_area = 10,
      pipe_covers = pipecoverspictures(),
      pipe_connections =
      {
        { position = {0.5, 2.5} }
      },
    },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-output"
    },
    horizontal_animation =
    {
      filename = "__FusionPower__/graphics/core_ent.png",
      width = 198,
      height = 198,
      frame_count = 1,
      line_length = 1,
     shift = {1,1}
    },
    vertical_animation =
    {
      filename = "__FusionPower__/graphics/core_ent.png",
      width = 198,
      height = 198,
      frame_count = 1,
      line_length = 1,
      shift = {1,1}
    },
    smoke =
    {
      {
        name = "light-smoke",
        north_position = {0.9, 0.0},
        east_position = {-2.0, -2.0},
        frequency = 10 / 32,
        starting_vertical_speed = 0.08,
        slow_down_factor = 1,
        starting_frame_deviation = 60
      }
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/steam-engine-90bpm.ogg",
        volume = 0.6
      },
      match_speed_to_activity = true,
    },
    min_perceived_performance = 0.25,
    performance_to_sound_speedup = 0.5
  },
  
  
  
  
  
  {
    type = "assembling-machine",
    name = "fusion-reactor",
    icon = "__FusionPower__/graphics/fusion.png",
    flags = {"placeable-neutral","placeable-player", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "fusion-reactor"},
    max_health = 300,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-1.5, -1.5}, {1.5, 1.5}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    module_specification =
    {
      module_slots = 4
    },
    allowed_effects = {"consumption", "speed", "productivity"},
    animation =
    {
      north =
      {
        filename = "__FusionPower__/graphics/fusion_ent.png",
        width = 156,
        height = 141,
        frame_count = 1,
        shift = {0.5, 0.1}
      }
    },
    working_visualisations =
    {
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound =
      {
        {
          filename = "__base__/sound/chemical-plant.ogg",
          volume = 0.8
        }
      },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 1.5,
    },
    crafting_speed = 1.0,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
    },
    energy_usage = "175000kW",
    ingredient_count = 2,
    crafting_categories = {"fusion"},
    fluid_boxes =
    {
      {
        production_type = "input",
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {-1, 2} }}
      },
      {
        production_type = "input",
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {1, 2} }}
      },
      {
        production_type = "output",
        pipe_covers = pipecoverspictures(),
        base_level = 1,
        pipe_connections = {{ position = {1, -2} }}
      }
    }
  },
  
  })