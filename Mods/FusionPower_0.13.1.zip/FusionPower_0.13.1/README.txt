This mod uses graphics being tech, thumbnail, and entity .png of the two objects listed below from the mod VersepellesDeepQuarry that can be found here:

https://mods.factorio.com/mods/Versepelles/VersepellesDeepQuarry

These images were provided under the following license:

https://creativecommons.org/licenses/by-nc/4.0/

As of VersepellesDeepQuarry mod version 1.2.2.

This is a list of resources used and what they're called in my mod.

MOD can be replaced with the directory of VersepellesDeepQuarry_1.2.2

MOD/graphics/icons/deep-quarry.png -> core.png
MOD/graphics/icons/deep-quarry-tech.png -> core_tech.png
MOD/graphics/icons/advanced-quarry.png -> fusion.png
MOD/graphics/icons/advanced-quarry-tech.png -> fusion_tech.png
MOD/graphics/entity/advanced-quarry/advanced-quarry.png -> fusion_ent.png
MOD/graphics/entity/deep-quarry/deep-quarry.png -> core_ent.png