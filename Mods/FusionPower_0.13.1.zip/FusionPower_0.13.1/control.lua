require "util"

script.on_event(defines.events.on_tick, function(event)
		check_generators()
end)

script.on_event(defines.events.on_built_entity, function(event)

	if event.created_entity.name == "plasma-generator" then	
			local plasma_reactor = event.created_entity
						if global.plasma_reactor == nil
						then global.plasma_reactor = {}
						end
					table.insert(global.plasma_reactor, plasma_reactor)
					plasma_reactor.fluidbox[1] = {type="hydrogen-plasma", amount=0, temperature=100}

	end
end)


script.on_event(defines.events.on_robot_built_entity, function(event)

	if event.created_entity.name == "plasma-generator" then		
			local plasma_reactor = event.created_entity
						if global.plasma_reactor == nil
						then global.plasma_reactor = {}
						end
					table.insert(global.plasma_reactor, plasma_reactor)
					plasma_reactor.fluidbox[1] = {type="hydrogen-plasma", amount=0, temperature=100}
	end
end)



function check_generators()
   if global.plasma_reactor ~= nil then

  	    for k,gen in pairs(global.plasma_reactor) do

			if gen.valid then
        		if gen.fluidbox[1] ~= nil then 
         			local pot = gen.fluidbox[1]
					--Set the temp high so that it
					--produces energy.
					if pot["type"] == "hydrogen-plasma" then
						pot["temperature"] = 1000
						local val = pot["amount"]
						val = val - 0.2
						if val < 0 then
							val = 0
						end
						pot["amount"] = val
					else
						pot["amount"] = 0
					end
					gen.fluidbox[1] = pot
				end				
			end
		
		end
	end
end