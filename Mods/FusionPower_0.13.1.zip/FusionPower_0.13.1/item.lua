data:extend({

{
    type = "item",
    name = "plasma-generator",
    icon = "__FusionPower__/graphics/core.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy",
	order = "b[steam-power]-a[boiler]",
	place_result = "plasma-generator",
    stack_size = 5
},

{
	type = "item",
	name = "fusion-reactor",
	icon = "__FusionPower__/graphics/fusion.png",
	flags = {"goes-to-quickbar"},
	subgroup = "energy",
	order = "b[steam-power]-a[boiler]",
	place_result = "fusion-reactor",
	stack_size = 1
}

})