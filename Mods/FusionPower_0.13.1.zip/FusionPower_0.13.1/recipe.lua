data:extend({
{
	type = "recipe",
	name = "plasma-generator",
	enabled = true,
	energy_required = 1,
	ingredients =
	{
		{type="item", name="steel-plate", amount=200},
		{type="item", name="electric-engine-unit", amount=30},
		{type="item", name="pipe", amount=10},
		{type="item", name="low-density-structure", amount=100},
		{type="item", name="effectivity-module-3", amount=5}
	},
	results = {
		{type="item", name="plasma-generator", amount=1}
	},
    icon = "__FusionPower__/graphics/core.png",
	order = "z"
},
{
	type = "recipe",
	name = "deuterium",
	enabled = false,
	category = "chemistry",
	energy_required = 3,
	ingredients =
	{
		{type="fluid", name="water", amount=100},
	},
	results = 
	{
		{type="fluid", name="deuterium", amount=5}
	},
    icon = "__FusionPower__/graphics/deuterium.png",
	order = "z"
},
{
	type = "recipe",
	name = "tritium",
	enabled = false,
	category = "chemistry",
	energy_required = 3,
	ingredients =
	{
		{type="fluid", name="deuterium", amount=30},
	},
	results = 
	{
		{type="fluid", name="tritium", amount=1}
	},
    icon = "__FusionPower__/graphics/tritium.png",
	order = "z"
},
{
	type = "recipe",
	name = "hydrogen-plasma",
	enabled = false,
	category = "fusion",
	energy_required = 3,
	ingredients =
	{
		{type="fluid", name="deuterium", amount=30},
		{type="fluid", name="tritium", amount=15},
	},
	results = 
	{
		{type="fluid", name="hydrogen-plasma", amount=60}
	},
    icon = "__FusionPower__/graphics/plasma.png",
	order = "z"
},
{
	type = "recipe-category",
	name = "fusion"
},
{
	type = "recipe",
	name = "fusion-reactor",
	enabled = true,
	energy_required = 10,
	ingredients =
	{
		{type="item", name="steel-plate", amount=300},
		{type="item", name="processing-unit", amount=160},
		{type="item", name="pipe", amount=30},
		{type="item", name="low-density-structure", amount=150},
		{type="item", name="speed-module-3", amount=20}
	},
	results = 
	{
		{type="item", name="fusion-reactor", amount=1}
	},
    icon = "__FusionPower__/graphics/fusion.png",
	order = "z"
}
})